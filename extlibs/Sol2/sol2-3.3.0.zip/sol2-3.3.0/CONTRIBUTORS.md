# 🎉 Donators! ♥ 🎉

Thank you to all patrons, donators and contributors who help keep sol2 amazing.

- Robert Salvet
- Ορφέας Ζαφείρης - 2x Donations!
- Michael Wallar
- Johannes Schultz
- Elias Daler
- BECKMANN & EGLE Industrieelektronik GmbH [bue.de](https://www.bue.de/)


# 🎉 Patrons! ♥ 🎉

Beyond just a one-time donation, patrons make a continued commitment to help keep sol2 supported and bug-free. Thank you for your patronage! Here are the supporters that wanted to be featured as sol2 contributors.

- Joel Falcou
- Michael Caisse
- Joshua Fisher
- Ορφέας Ζαφείρης


# Company Patrons / Supporters #

Companies who sign up for a long-term support contract or patronage are listed here! They really push forward what's possible with sol2 (and the newer v3)! Please reach out to phdofthehouse@gmail.com if you are interested in a custom solution or a long-term support contract that goes beyond the current release's needs!

- Intrepid Control Systems [intrepidcs.com](https://www.intrepidcs.com/)
